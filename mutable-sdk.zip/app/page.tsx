"use client"

import  from "../rollup.config"

export default function SyntheticV0PageForDeployment() {
  return < />
}