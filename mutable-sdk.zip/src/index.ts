/**
 * Mutable SDK
 *
 * Main entry point for the SDK
 */

// Export core SDK
export { MutableSDK } from "./core/mutable-sdk"

// Export modules
export { AuthModule } from "./modules/auth"
export { GameStateModule } from "./modules/game-state"
export { TransactionsModule } from "./modules/transactions"
export { AnalyticsModule } from "./modules/analytics"
export { UnityBridgeModule } from "./modules/unity-bridge"

// Export types
export * from "./types"

// Export utility functions
export * from "./utils"

// Export version
export const VERSION = "1.0.0"
