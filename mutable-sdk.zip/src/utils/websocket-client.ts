/**
 * WebSocket Client
 *
 * Handles WebSocket connections to the Mutable platform.
 */

import { type MutableSDKConfig, ErrorCode, MutableSDKError } from "../types"
import type { Logger } from "./logger"

export class WebSocketClient {
  private config: MutableSDKConfig
  private logger: Logger
  private socket: WebSocket | null = null
  private messageHandlers: Map<string, (data: any) => void> = new Map()
  private reconnectAttempts = 0
  private maxReconnectAttempts = 5
  private reconnectTimeout: NodeJS.Timeout | null = null
  private authToken?: string

  constructor(config: MutableSDKConfig, logger: Logger) {
    this.config = config
    this.logger = logger
  }

  /**
   * Set the authentication token
   * @param token Authentication token
   */
  public setAuthToken(token: string): void {
    this.authToken = token
  }

  /**
   * Connect to the WebSocket server
   */
  public connect(): Promise<void> {
    return new Promise((resolve, reject) => {
      try {
        // Build WebSocket URL with auth token if available
        let url = this.config.websocketUrl!
        if (this.authToken) {
          url += `?token=${this.authToken}`
        }

        this.logger.info("Connecting to WebSocket", { url })

        this.socket = new WebSocket(url)

        this.socket.onopen = () => {
          this.logger.info("WebSocket connection established")
          this.reconnectAttempts = 0
          resolve()
        }

        this.socket.onmessage = (event) => {
          try {
            const message = JSON.parse(event.data)
            const { type, data } = message

            this.logger.debug("WebSocket message received", { type, data })

            const handler = this.messageHandlers.get(type)
            if (handler) {
              handler(data)
            }
          } catch (error) {
            this.logger.error("Error parsing WebSocket message", error)
          }
        }

        this.socket.onerror = (error) => {
          this.logger.error("WebSocket error", error)
          reject(new MutableSDKError(ErrorCode.CONNECTION_ERROR, "WebSocket connection error"))
        }

        this.socket.onclose = (event) => {
          this.logger.info("WebSocket connection closed", { code: event.code, reason: event.reason })
          this.attemptReconnect()
        }
      } catch (error) {
        this.logger.error("Error connecting to WebSocket", error)
        reject(new MutableSDKError(ErrorCode.CONNECTION_ERROR, "Failed to connect to WebSocket", error))
      }
    })
  }

  /**
   * Send a message to the WebSocket server
   * @param type Message type
   * @param data Message data
   */
  public send(type: string, data: any): void {
    if (!this.socket || this.socket.readyState !== WebSocket.OPEN) {
      this.logger.warn("WebSocket is not connected, cannot send message")
      return
    }

    try {
      const message = JSON.stringify({ type, data })
      this.socket.send(message)
      this.logger.debug("WebSocket message sent", { type, data })
    } catch (error) {
      this.logger.error("Error sending WebSocket message", error)
      throw new MutableSDKError(ErrorCode.CONNECTION_ERROR, "Failed to send WebSocket message", error)
    }
  }

  /**
   * Register a handler for a specific message type
   * @param type Message type
   * @param handler Function to call when message is received
   */
  public on(type: string, handler: (data: any) => void): void {
    this.messageHandlers.set(type, handler)
  }

  /**
   * Unregister a handler for a specific message type
   * @param type Message type
   */
  public off(type: string): void {
    this.messageHandlers.delete(type)
  }

  /**
   * Disconnect from the WebSocket server
   */
  public disconnect(): void {
    if (this.reconnectTimeout) {
      clearTimeout(this.reconnectTimeout)
      this.reconnectTimeout = null
    }

    if (this.socket) {
      this.socket.close()
      this.socket = null
    }

    this.logger.info("WebSocket disconnected")
  }

  /**
   * Check if the WebSocket is connected
   */
  public isConnected(): boolean {
    return !!this.socket && this.socket.readyState === WebSocket.OPEN
  }

  /**
   * Attempt to reconnect to the WebSocket server
   */
  private attemptReconnect(): void {
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      this.logger.warn("Maximum reconnect attempts reached, giving up")
      return
    }

    this.reconnectAttempts++
    const delay = Math.min(1000 * Math.pow(2, this.reconnectAttempts), 30000)

    this.logger.info(
      `Attempting to reconnect in ${delay}ms (attempt ${this.reconnectAttempts}/${this.maxReconnectAttempts})`,
    )

    this.reconnectTimeout = setTimeout(() => {
      this.connect().catch(() => {
        this.attemptReconnect()
      })
    }, delay)
  }
}
