/**
 * API Client
 *
 * Handles HTTP requests to the Mutable API.
 */

import type { MutableSDKConfig } from "../types"
import type { Logger } from "./logger"

interface ApiResponse<T = any> {
  success: boolean
  data?: T
  error?: string
}

export class ApiClient {
  private config: MutableSDKConfig
  private logger: Logger
  private authToken?: string

  constructor(config: MutableSDKConfig, logger: Logger) {
    this.config = config
    this.logger = logger
  }

  /**
   * Set the authentication token
   * @param token Authentication token
   */
  public setAuthToken(token: string): void {
    this.authToken = token
  }

  /**
   * Make a GET request
   * @param endpoint API endpoint
   * @param params Query parameters
   */
  public async get<T = any>(endpoint: string, params?: Record<string, any>): Promise<ApiResponse<T>> {
    try {
      let url = `${this.config.apiUrl}${endpoint}`

      // Add query parameters
      if (params) {
        const queryParams = new URLSearchParams()
        for (const [key, value] of Object.entries(params)) {
          queryParams.append(key, String(value))
        }
        url += `?${queryParams.toString()}`
      }

      this.logger.debug(`GET ${url}`)

      const response = await fetch(url, {
        method: "GET",
        headers: this.getHeaders(),
      })

      return this.handleResponse<T>(response)
    } catch (error) {
      this.logger.error(`GET ${endpoint} failed`, error)
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
      }
    }
  }

  /**
   * Make a POST request
   * @param endpoint API endpoint
   * @param body Request body
   */
  public async post<T = any>(endpoint: string, body: any): Promise<ApiResponse<T>> {
    try {
      const url = `${this.config.apiUrl}${endpoint}`

      this.logger.debug(`POST ${url}`, body)

      const response = await fetch(url, {
        method: "POST",
        headers: this.getHeaders(),
        body: JSON.stringify(body),
      })

      return this.handleResponse<T>(response)
    } catch (error) {
      this.logger.error(`POST ${endpoint} failed`, error)
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
      }
    }
  }

  /**
   * Make a PUT request
   * @param endpoint API endpoint
   * @param body Request body
   */
  public async put<T = any>(endpoint: string, body: any): Promise<ApiResponse<T>> {
    try {
      const url = `${this.config.apiUrl}${endpoint}`

      this.logger.debug(`PUT ${url}`, body)

      const response = await fetch(url, {
        method: "PUT",
        headers: this.getHeaders(),
        body: JSON.stringify(body),
      })

      return this.handleResponse<T>(response)
    } catch (error) {
      this.logger.error(`PUT ${endpoint} failed`, error)
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
      }
    }
  }

  /**
   * Make a DELETE request
   * @param endpoint API endpoint
   */
  public async delete<T = any>(endpoint: string): Promise<ApiResponse<T>> {
    try {
      const url = `${this.config.apiUrl}${endpoint}`

      this.logger.debug(`DELETE ${url}`)

      const response = await fetch(url, {
        method: "DELETE",
        headers: this.getHeaders(),
      })

      return this.handleResponse<T>(response)
    } catch (error) {
      this.logger.error(`DELETE ${endpoint} failed`, error)
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
      }
    }
  }

  /**
   * Handle API response
   * @param response Fetch response
   */
  private async handleResponse<T>(response: Response): Promise<ApiResponse<T>> {
    try {
      const contentType = response.headers.get("content-type")

      // Parse JSON response if content type is JSON
      let data
      if (contentType && contentType.includes("application/json")) {
        data = await response.json()
      } else {
        data = await response.text()
      }

      if (!response.ok) {
        return {
          success: false,
          error: data.error || data.message || `HTTP error ${response.status}`,
        }
      }

      return {
        success: true,
        data: data as T,
      }
    } catch (error) {
      this.logger.error("Failed to parse API response", error)
      return {
        success: false,
        error: "Failed to parse API response",
      }
    }
  }

  /**
   * Get request headers
   */
  private getHeaders(): Record<string, string> {
    const headers: Record<string, string> = {
      "Content-Type": "application/json",
      "X-API-Key": this.config.apiKey,
    }

    if (this.authToken) {
      headers["Authorization"] = `Bearer ${this.authToken}`
    }

    return headers
  }
}
